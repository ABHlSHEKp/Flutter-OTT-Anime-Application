import 'package:flutter/material.dart';

const randomColors = [
  Colors.white54,
  Colors.amber,
  Colors.blue,
  Colors.orange,
  Colors.cyan,
  Colors.teal,
  Colors.pink,
  Colors.redAccent,
  Colors.purple,
  Colors.green,
  Colors.lime,
];
